// do not remove, allowes autocomplete
/// <reference path="./../p5.global-mode.d.ts" />

function setup() {
  // put setup code here
  createCanvas(400, 400);
  rect(10, 10, 100, 100);
}

function draw() {
  // put drawing code here
}
